AI-BlogNest API Phase-wise Documentation
Date: 27-09-2026

This set contains 13 editable Word documents adapted from the supplied phase-wise templates. Project-specific statements are based on the provided project details and API screenshots. The planning dates and story-point estimates are proposed planning values. UAT records distinguish screenshot-confirmed outcomes from scenarios not shown in supplied evidence.

Team Leader: S. Rushyan
Team Members: K. Anandhan, M. Neelakandan, M. Sanjay, D. Jeevan Kumar
Department: Computer Science
